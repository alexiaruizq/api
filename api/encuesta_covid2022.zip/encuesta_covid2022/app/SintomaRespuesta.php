<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SintomaRespuesta extends Model
{
    protected $table = "sintomas_respuesta";
}
